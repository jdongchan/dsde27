# 반복문을 사용하여 학생들의 총점과 평균을 출력하자
students = {'홍길동': 76, '이순신': 91, '김선달': 83}

score_sum = 0
score_avg = 0
for value in students.values():
    score_sum += value
score_avg = score_sum / len(students.values())


print(f'총점 : {score_sum} \t 평균 : {score_avg: .2f}')
