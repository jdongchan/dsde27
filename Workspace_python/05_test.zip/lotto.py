from random import randint


# 1 ~ 45 까지의 중복되지 않는 랜덤한 숫자 6개를 정렬하여 리턴하자
def make() -> list:
    pass


if __name__ == '__main__':
    print(make())
