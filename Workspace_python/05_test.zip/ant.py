'''
출력 예)
1
11
12
1121
122111
112213
'''


def ant(i: int) -> str:
    pass


if __name__ == '__main__':
    pass
