'''
*
**
***
****
*****
'''
def star01():
    pass




'''
*****
****
***
**
*
'''
def star02():
    pass




'''
    *
   **
  ***
 ****
*****
'''
def star03():
    pass




'''
*****
 ****
  ***
   **
    *
'''
def star04():
    pass




'''
    *
   ***
  *****
 *******
*********
'''
def star05():
    pass


if __name__ == '__main__':
    star01()
    star02()
    star03()
    star04()
    star05()
